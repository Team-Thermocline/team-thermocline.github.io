#ifndef _BOARD_PINS_H
#define _BOARD_PINS_H

// LEDs
#define STAT_LED 13

#endif
